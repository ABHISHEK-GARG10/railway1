# RailwayEnquiry
This android application tells about train details (status, route, seat availability, pnr and train between stations) in India.
